function CalculoInteresFijo (base, interes, mes, meses, limite) {
	valorFinal = base
	while(valorFinal < limite) {
        console.log(mes + " " + valorFinal)
        valorFinal += interes
        mes ++
    }
    console.log(mes + " " + valorFinal)
    return mes + " " + valorFinal
}

var container = document.getElementById("demo");
container.innerHTML = CalculoInteresFijo(1000.0, 10.5, 0, 12, 1300);
